/* eslint-disable no-undef */
importScripts('initialize.js');
importScripts('contextMenu.js');
